public class Main {
    public static void main(String[] args) {

        String title = "Приветсвтвенный экран";
        GUI gui = new GUI(title);
        gui.setVisible(true);

    }
}
